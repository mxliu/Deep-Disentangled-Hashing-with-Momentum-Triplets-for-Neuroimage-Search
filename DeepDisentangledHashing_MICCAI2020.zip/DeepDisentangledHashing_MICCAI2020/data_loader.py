# -*- coding: utf-8 -*-
"""
Created on Mon Sep 16 22:03:56 2019

@author: guanhao
"""
import torch
#from torch import nn, optim
from torchvision import datasets
#from torchvision.transforms import Compose, ToTensor,Normalize
import numpy as np
import scipy.io as sio
from torch.utils.data import Dataset, DataLoader

import os

class ADNI2_Dataset(Dataset):
    def __init__(self, transform = None):
        #mat_path = './data/ADNI_1_MRI'
        data_AD = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_2_MRI/ADNI_2_AD.mat')
        Xa, Ya = data_AD['X'], data_AD['Y']
        Xa = Xa.astype('float32')
        Xa /= 255                         #normalized to [0,1.0]
        Xa = np.expand_dims(Xa, axis = 1) #add channel=1 to the data, n * c * H * W
        Ya = Ya.astype('int64')
        
        data_CN = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_2_MRI/ADNI_2_CN.mat')
        Xc, Yc = data_CN['X'], data_CN['Y']
        Xc = Xc.astype('float32')
        Xc /= 255                         #normalized to [0,1.0]
        Xc = np.expand_dims(Xc, axis = 1) #add channel=1 to the data, n * c * H * W
        Yc = Yc.astype('int64')

        data_pMCI = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_2_MRI/ADNI_2_pMCI.mat')
        Xpm, Ypm = data_pMCI['X'], data_pMCI['Y']
        Xpm = Xpm.astype('float32')
        Xpm /= 255                         #normalized to [0,1.0]
        Xpm = np.expand_dims(Xpm, axis = 1) #add channel=1 to the data, n * c * H * W
        Ypm = Ypm.astype('int64')*0 + 2
        
        data_sMCI = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_2_MRI/ADNI_2_sMCI.mat')
        Xsm, Ysm = data_sMCI['X'], data_sMCI['Y']
        Xsm = Xsm.astype('float32')
        Xsm /= 255                         #normalized to [0,1.0]
        Xsm = np.expand_dims(Xsm, axis = 1) #add channel=1 to the data, n * c * H * W
        Ysm = Ysm.astype('int64')*0 + 2
        
        XX = np.vstack((Xa,Xc, Xpm, Xsm))
        YY = np.vstack((Ya,Yc, Ypm, Ysm))
        
        self.images = torch.from_numpy(XX) 
        self.targets = torch.from_numpy(YY) 
        #self.transform = transform

    def __getitem__(self, index):
        x = self.images[index]
        y = self.targets[index]
        return x, y

    def __len__(self):
        return len(self.images)


class ADNI1_Dataset(Dataset):
    def __init__(self, transform = None):
        #mat_path = './data/ADNI_1_MRI'
        data_AD = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_1_MRI/ADNI_1_AD.mat')
        Xa, Ya = data_AD['X'], data_AD['Y']
        Xa = Xa.astype('float32')
        Xa /= 255                         #normalized to [0,1.0]
        Xa = np.expand_dims(Xa, axis = 1) #add channel=1 to the data, n * c * H * W
        Ya = Ya.astype('int64')
        
        data_CN = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_1_MRI/ADNI_1_CN.mat')
        Xc, Yc = data_CN['X'], data_CN['Y']
        Xc = Xc.astype('float32')
        Xc /= 255                         #normalized to [0,1.0]
        Xc = np.expand_dims(Xc, axis = 1) #add channel=1 to the data, n * c * H * W
        Yc = Yc.astype('int64')

        data_pMCI = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_1_MRI/ADNI_1_pMCI.mat')
        Xpm, Ypm = data_pMCI['X'], data_pMCI['Y']
        Xpm = Xpm.astype('float32')
        Xpm /= 255                         #normalized to [0,1.0]
        Xpm = np.expand_dims(Xpm, axis = 1) #add channel=1 to the data, n * c * H * W
        Ypm = Ypm.astype('int64')*0 + 2
        
        data_sMCI = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_1_MRI/ADNI_1_sMCI.mat')
        Xsm, Ysm = data_sMCI['X'], data_sMCI['Y']
        Xsm = Xsm.astype('float32')
        Xsm /= 255                         #normalized to [0,1.0]
        Xsm = np.expand_dims(Xsm, axis = 1) #add channel=1 to the data, n * c * H * W
        Ysm = Ysm.astype('int64')*0 + 2
        
        XX = np.vstack((Xa,Xc, Xpm, Xsm))
        YY = np.vstack((Ya,Yc, Ypm, Ysm))
        
        self.images = torch.from_numpy(XX) 
        self.targets = torch.from_numpy(YY) 
        #self.transform = transform

    def __getitem__(self, index):
        x = self.images[index]
        y = self.targets[index]
        return x, y

    def __len__(self):
        return len(self.images)

class ADNI1_Dataset_AD(Dataset):
    def __init__(self, transform = None):
        #mat_path = './data/ADNI_1_MRI'
        data_AD = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_1_MRI/ADNI_1_AD.mat')
        Xa, Ya = data_AD['X'], data_AD['Y']
        Xa = Xa.astype('float32')
        Xa /= 255                         #normalized to [0,1.0]
        Xa = np.expand_dims(Xa, axis = 1) #add channel=1 to the data, n * c * H * W
        Ya = Ya.astype('int64')
        
        data_CN = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_1_MRI/ADNI_1_CN.mat')
        Xc, Yc = data_CN['X'], data_CN['Y']
        Xc = Xc.astype('float32')
        Xc /= 255                         #normalized to [0,1.0]
        Xc = np.expand_dims(Xc, axis = 1) #add channel=1 to the data, n * c * H * W
        Yc = Yc.astype('int64')
        
        XX = np.vstack((Xa,Xc))
        YY = np.vstack((Ya,Yc))
        
        self.images = torch.from_numpy(XX) 
        self.targets = torch.from_numpy(YY) 
        #self.transform = transform

    def __getitem__(self, index):
        x = self.images[index]
        y = self.targets[index]
        return x, y

    def __len__(self):
        return len(self.images)

class ADNI1_Dataset_AD_train(Dataset):
    def __init__(self, transform = None):
        #mat_path = './data/ADNI_1_MRI'
        data_AD = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_1_MRI/ADNI_1_AD.mat')
        Xa, Ya = data_AD['X'], data_AD['Y']
        Xa = Xa.astype('float32')
        Xa /= 255                         #normalized to [0,1.0]
        Xa = np.expand_dims(Xa, axis = 1) #add channel=1 to the data, n * c * H * W
        Ya = Ya.astype('int64')
        ton = len(Xa)
        trn = int(np.round(ton*0.9))
        Xa = Xa[trn:,:,:,:]
        Ya = Ya[trn:,:]
        
        data_CN = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_1_MRI/ADNI_1_CN.mat')
        Xc, Yc = data_CN['X'], data_CN['Y']
        Xc = Xc.astype('float32')
        Xc /= 255                         #normalized to [0,1.0]
        Xc = np.expand_dims(Xc, axis = 1) #add channel=1 to the data, n * c * H * W
        Yc = Yc.astype('int64')
        ton = len(Xc)
        trn = int(np.round(ton*0.9))
        Xc = Xc[trn:,:,:,:]
        Yc = Yc[trn:,:]
        
        XX = np.vstack((Xa,Xc))
        YY = np.vstack((Ya,Yc))
        
        self.images = torch.from_numpy(XX) 
        self.targets = torch.from_numpy(YY) 
        #self.transform = transform

    def __getitem__(self, index):
        x = self.images[index]
        y = self.targets[index]
        return x, y

    def __len__(self):
        return len(self.images)
    
    
#######################################################################

class ADNI1_Dataset_MCI(Dataset):
    def __init__(self, transform = None):
        #mat_path = './data/ADNI_1_MRI'
        data_pMCI = sio.loadmat('./data/ADNI_1_MRI/ADNI_1_pMCI.mat')
        Xa, Ya = data_pMCI['X'], data_pMCI['Y']
        Xa = Xa.astype('float32')
        Xa /= 255                         #normalized to [0,1.0]
        Xa = np.expand_dims(Xa, axis = 1) #add channel=1 to the data, n * c * H * W
        Ya = Ya.astype('int64')
        
        data_sMCI = sio.loadmat('./data/ADNI_1_MRI/ADNI_1_sMCI.mat')
        Xc, Yc = data_sMCI['X'], data_sMCI['Y']
        Xc = Xc.astype('float32')
        Xc /= 255                         #normalized to [0,1.0]
        Xc = np.expand_dims(Xc, axis = 1) #add channel=1 to the data, n * c * H * W
        Yc = Yc.astype('int64')
        
        XX = np.vstack((Xa,Xc))
        YY = np.vstack((Ya,Yc))
        
        self.images = torch.from_numpy(XX) 
        self.targets = torch.from_numpy(YY) 
        #self.transform = transform

    def __getitem__(self, index):
        x = self.images[index]
        y = self.targets[index]
        return x, y

    def __len__(self):
        return len(self.images)
    
#######################################################################
        
class ADNI2_Dataset_AD(Dataset):
    def __init__(self, transform = None):
        #mat_path = './data/ADNI_1_MRI'
        data_AD = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_2_MRI/ADNI_2_AD.mat')
        #data_AD = sio.loadmat('./data/ADNI_2_MRI/ADNI_2_AD.mat')
        Xa, Ya = data_AD['X'], data_AD['Y']
        Xa = Xa.astype('float32')
        Xa /= 255                         #normalized to [0,1.0]
        Xa = np.expand_dims(Xa, axis = 1) #add channel=1 to the data, n * c * H * W
        Ya = Ya.astype('int64')
        
        data_CN = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_2_MRI/ADNI_2_CN.mat')
        Xc, Yc = data_CN['X'], data_CN['Y']
        Xc = Xc.astype('float32')
        Xc /= 255                         #normalized to [0,1.0]
        Xc = np.expand_dims(Xc, axis = 1) #add channel=1 to the data, n * c * H * W
        Yc = Yc.astype('int64')
        
        XX = np.vstack((Xa,Xc))
        YY = np.vstack((Ya,Yc))
        
        self.images = torch.from_numpy(XX) 
        self.targets = torch.from_numpy(YY) 
        #self.transform = transform

    def __getitem__(self, index):
        x = self.images[index]
        y = self.targets[index]
        return x, y

    def __len__(self):
        return len(self.images)  

class ADNI2_Dataset_AD_train(Dataset):
    def __init__(self, transform = None):
        #mat_path = './data/ADNI_1_MRI'
        data_AD = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_2_MRI/ADNI_2_AD.mat')
        #data_AD = sio.loadmat('./data/ADNI_2_MRI/ADNI_2_AD.mat')
        Xa, Ya = data_AD['X'], data_AD['Y']
        Xa = Xa.astype('float32')
        Xa /= 255                         #normalized to [0,1.0]
        Xa = np.expand_dims(Xa, axis = 1) #add channel=1 to the data, n * c * H * W
        Ya = Ya.astype('int64')
        ton = len(Xa)
        trn = int(np.round(ton*0.9))
        Xa = Xa[trn:,:,:,:]
        Ya = Ya[trn:,:]
        
        data_CN = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_2_MRI/ADNI_2_CN.mat')
        Xc, Yc = data_CN['X'], data_CN['Y']
        Xc = Xc.astype('float32')
        Xc /= 255                         #normalized to [0,1.0]
        Xc = np.expand_dims(Xc, axis = 1) #add channel=1 to the data, n * c * H * W
        Yc = Yc.astype('int64')
        ton = len(Xc)
        trn = int(np.round(ton*0.9))
        Xc = Xc[trn:,:,:,:]
        Yc = Yc[trn:,:]
        
        XX = np.vstack((Xa,Xc))
        YY = np.vstack((Ya,Yc))
        
        self.images = torch.from_numpy(XX) 
        self.targets = torch.from_numpy(YY) 
        #self.transform = transform

    def __getitem__(self, index):
        x = self.images[index]
        y = self.targets[index]
        return x, y

    def __len__(self):
        return len(self.images)  
    
    
#######################################################################
        
class ADNI2_Dataset_MCI(Dataset):
    def __init__(self, transform = None):
        #mat_path = './data/ADNI_1_MRI'
        data_pMCI = sio.loadmat('./data/ADNI_2_MRI/ADNI_2_pMCI.mat')
        Xa, Ya = data_pMCI['X'], data_pMCI['Y']
        Xa = Xa.astype('float32')
        Xa /= 255                         #normalized to [0,1.0]
        Xa = np.expand_dims(Xa, axis = 1) #add channel=1 to the data, n * c * H * W
        Ya = Ya.astype('int64')
        
        data_sMCI = sio.loadmat('./data/ADNI_2_MRI/ADNI_2_sMCI.mat')
        Xc, Yc = data_sMCI['X'], data_sMCI['Y']
        Xc = Xc.astype('float32')
        Xc /= 255                         #normalized to [0,1.0]
        Xc = np.expand_dims(Xc, axis = 1) #add channel=1 to the data, n * c * H * W
        Yc = Yc.astype('int64')
        
        XX = np.vstack((Xa,Xc))
        YY = np.vstack((Ya,Yc))
        
        self.images = torch.from_numpy(XX) 
        self.targets = torch.from_numpy(YY) 
        #self.transform = transform

    def __getitem__(self, index):
        x = self.images[index]
        y = self.targets[index]
        return x, y

    def __len__(self):
        return len(self.images)


#######################################################################
        
class AIBL_Dataset_AD(Dataset):
    def __init__(self, transform = None):
        #mat_path = './data/ADNI_1_MRI'
        data_AD = sio.loadmat('./data/AIBL_AD.mat')
        Xa, Ya = data_AD['X'], data_AD['Y']
        Xa = Xa.astype('float32')
        Xa /= 255                         #normalized to [0,1.0]
        Xa = np.expand_dims(Xa, axis = 1) #add channel=1 to the data, n * c * H * W
        Ya = Ya.astype('int64')
        
        data_CN = sio.loadmat('./data/AIBL_CN.mat')
        Xc, Yc = data_CN['X'], data_CN['Y']
        Xc = Xc.astype('float32')
        Xc /= 255                         #normalized to [0,1.0]
        Xc = np.expand_dims(Xc, axis = 1) #add channel=1 to the data, n * c * H * W
        Yc = Yc.astype('int64')
        
        XX = np.vstack((Xa,Xc))
        YY = np.vstack((Ya,Yc))
        
        self.images = torch.from_numpy(XX) 
        self.targets = torch.from_numpy(YY) 
        #self.transform = transform

    def __getitem__(self, index):
        x = self.images[index]
        y = self.targets[index]
        return x, y

    def __len__(self):
        return len(self.images)  

#######################################################################
        
class AIBL_Dataset_MCI(Dataset):
    def __init__(self, transform = None):
        #mat_path = './data/ADNI_1_MRI'
        data_pMCI = sio.loadmat('./data/AIBL_pMCI.mat')
        Xa, Ya = data_pMCI['X'], data_pMCI['Y']
        Xa = Xa.astype('float32')
        Xa /= 255                         #normalized to [0,1.0]
        Xa = np.expand_dims(Xa, axis = 1) #add channel=1 to the data, n * c * H * W
        Ya = Ya.astype('int64')
        
        data_sMCI = sio.loadmat('./data/AIBL_sMCI.mat')
        Xc, Yc = data_sMCI['X'], data_sMCI['Y']
        Xc = Xc.astype('float32')
        Xc /= 255                         #normalized to [0,1.0]
        Xc = np.expand_dims(Xc, axis = 1) #add channel=1 to the data, n * c * H * W
        Yc = Yc.astype('int64')
        
        XX = np.vstack((Xa,Xc))
        YY = np.vstack((Ya,Yc))
        
        self.images = torch.from_numpy(XX) 
        self.targets = torch.from_numpy(YY) 
        #self.transform = transform

    def __getitem__(self, index):
        x = self.images[index]
        y = self.targets[index]
        return x, y

    def __len__(self):
        return len(self.images)  
#####################################################################################################
class ADNI12_Dataset_AD(Dataset):
    def __init__(self, transform = None):
        #mat_path = './data/ADNI_1_MRI'
        data_AD = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_1_MRI/ADNI_1_AD.mat')
        Xa, Ya = data_AD['X'], data_AD['Y']
        Xa = Xa.astype('float32')
        Xa /= 255                         #normalized to [0,1.0]
        Xa = np.expand_dims(Xa, axis = 1) #add channel=1 to the data, n * c * H * W
        Ya = Ya.astype('int64')
        
        data_CN = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_1_MRI/ADNI_1_CN.mat')
        Xc, Yc = data_CN['X'], data_CN['Y']
        Xc = Xc.astype('float32')
        Xc /= 255                         #normalized to [0,1.0]
        Xc = np.expand_dims(Xc, axis = 1) #add channel=1 to the data, n * c * H * W
        Yc = Yc.astype('int64')
        
        data_AD2 = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_2_MRI/ADNI_2_AD.mat')
        Xa2, Ya2 = data_AD2['X'], data_AD2['Y']
        Xa2 = Xa2.astype('float32')
        Xa2 /= 255                         #normalized to [0,1.0]
        Xa2 = np.expand_dims(Xa2, axis = 1) #add channel=1 to the data, n * c * H * W
        Ya2 = Ya2.astype('int64')
        
        data_CN2 = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_2_MRI/ADNI_2_CN.mat')
        Xc2, Yc2 = data_CN2['X'], data_CN2['Y']
        Xc2 = Xc2.astype('float32')
        Xc2 /= 255                         #normalized to [0,1.0]
        Xc2 = np.expand_dims(Xc2, axis = 1) #add channel=1 to the data, n * c * H * W
        Yc2 = Yc2.astype('int64')
        
        XX = np.vstack((Xa,Xc,Xa2,Xc2))
        YY = np.vstack((Ya,Yc,Ya2,Yc2))
        
        self.images = torch.from_numpy(XX) 
        self.targets = torch.from_numpy(YY) 
        #self.transform = transform

    def __getitem__(self, index):
        x = self.images[index]
        y = self.targets[index]
        return x, y

    def __len__(self):
        return len(self.images)     
###################################################################################################

class ADNI12_Dataset_MCI(Dataset):
    def __init__(self, transform = None):
        #mat_path = './data/ADNI_1_MRI'
        data_pMCI = sio.loadmat('./data/ADNI_1_MRI/ADNI_1_pMCI.mat')
        Xa, Ya = data_pMCI['X'], data_pMCI['Y']
        Xa = Xa.astype('float32')
        Xa /= 255                         #normalized to [0,1.0]
        Xa = np.expand_dims(Xa, axis = 1) #add channel=1 to the data, n * c * H * W
        Ya = Ya.astype('int64')
        
        data_sMCI = sio.loadmat('./data/ADNI_1_MRI/ADNI_1_sMCI.mat')
        Xc, Yc = data_sMCI['X'], data_sMCI['Y']
        Xc = Xc.astype('float32')
        Xc /= 255                         #normalized to [0,1.0]
        Xc = np.expand_dims(Xc, axis = 1) #add channel=1 to the data, n * c * H * W
        Yc = Yc.astype('int64')
        
        data_pMCI2 = sio.loadmat('./data/ADNI_2_MRI/ADNI_2_pMCI.mat')
        Xa2, Ya2 = data_pMCI2['X'], data_pMCI2['Y']
        Xa2 = Xa2.astype('float32')
        Xa2 /= 255                         #normalized to [0,1.0]
        Xa2 = np.expand_dims(Xa2, axis = 1) #add channel=1 to the data, n * c * H * W
        Ya2 = Ya2.astype('int64')
        
        data_sMCI2 = sio.loadmat('./data/ADNI_2_MRI/ADNI_2_sMCI.mat')
        Xc2, Yc2 = data_sMCI2['X'], data_sMCI2['Y']
        Xc2 = Xc2.astype('float32')
        Xc2 /= 255                         #normalized to [0,1.0]
        Xc2 = np.expand_dims(Xc2, axis = 1) #add channel=1 to the data, n * c * H * W
        Yc2 = Yc2.astype('int64')
        
        XX = np.vstack((Xa,Xc,Xa2,Xc2))
        YY = np.vstack((Ya,Yc,Ya2,Yc2))
        
        self.images = torch.from_numpy(XX) 
        self.targets = torch.from_numpy(YY) 
        #self.transform = transform

    def __getitem__(self, index):
        x = self.images[index]
        y = self.targets[index]
        return x, y

    def __len__(self):
        return len(self.images)      
    
class ADNI2_Dataset_train(Dataset):
    def __init__(self, transform = None):
        #mat_path = './data/ADNI_1_MRI'
        data_AD = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_2_MRI/ADNI_2_AD.mat')
        Xa, Ya = data_AD['X'], data_AD['Y']
        Xa = Xa.astype('float32')
        Xa /= 255                         #normalized to [0,1.0]
        Xa = np.expand_dims(Xa, axis = 1) #add channel=1 to the data, n * c * H * W
        Ya = Ya.astype('int64')
        ton = len(Xa)
        trn = int(np.round(ton*0.9))
        Xa = Xa[0:trn,:,:,:]
        Ya = Ya[0:trn,:]
        
        data_CN = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_2_MRI/ADNI_2_CN.mat')
        Xc, Yc = data_CN['X'], data_CN['Y']
        Xc = Xc.astype('float32')
        Xc /= 255                         #normalized to [0,1.0]
        Xc = np.expand_dims(Xc, axis = 1) #add channel=1 to the data, n * c * H * W
        Yc = Yc.astype('int64')
        ton = len(Xc)
        trn = int(np.round(ton*0.9))
        Xc = Xc[0:trn,:,:,:]
        Yc = Yc[0:trn,:]

        data_pMCI = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_2_MRI/ADNI_2_pMCI.mat')
        Xpm, Ypm = data_pMCI['X'], data_pMCI['Y']
        Xpm = Xpm.astype('float32')
        Xpm /= 255                         #normalized to [0,1.0]
        Xpm = np.expand_dims(Xpm, axis = 1) #add channel=1 to the data, n * c * H * W
        Ypm = Ypm.astype('int64')*0 + 2
        ton = len(Xpm)
        trn = int(np.round(ton*0.9))
        Xpm = Xpm[0:trn,:,:,:]
        Ypm = Ypm[0:trn,:]
        
        data_sMCI = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_2_MRI/ADNI_2_sMCI.mat')
        Xsm, Ysm = data_sMCI['X'], data_sMCI['Y']
        Xsm = Xsm.astype('float32')
        Xsm /= 255                         #normalized to [0,1.0]
        Xsm = np.expand_dims(Xsm, axis = 1) #add channel=1 to the data, n * c * H * W
        Ysm = Ysm.astype('int64')*0 + 2
        ton = len(Xsm)
        trn = int(np.round(ton*0.9))
        Xsm = Xsm[0:trn,:,:,:]
        Ysm = Ysm[0:trn,:]
        
        XX = np.vstack((Xa,Xc, Xpm, Xsm))
        YY = np.vstack((Ya,Yc, Ypm, Ysm))
        
        self.images = torch.from_numpy(XX) 
        self.targets = torch.from_numpy(YY) 
        #self.transform = transform

    def __getitem__(self, index):
        x = self.images[index]
        y = self.targets[index]
        return x, y

    def __len__(self):
        return len(self.images)

class ADNI2_Dataset_test(Dataset):
    def __init__(self, transform = None):
        #mat_path = './data/ADNI_1_MRI'
        data_AD = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_2_MRI/ADNI_2_AD.mat')
        Xa, Ya = data_AD['X'], data_AD['Y']
        Xa = Xa.astype('float32')
        Xa /= 255                         #normalized to [0,1.0]
        Xa = np.expand_dims(Xa, axis = 1) #add channel=1 to the data, n * c * H * W
        Ya = Ya.astype('int64')
        ton = len(Xa)
        trn = int(np.round(ton*0.9))
        Xa = Xa[trn:,:,:,:]
        Ya = Ya[trn:,:]
        
        data_CN = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_2_MRI/ADNI_2_CN.mat')
        Xc, Yc = data_CN['X'], data_CN['Y']
        Xc = Xc.astype('float32')
        Xc /= 255                         #normalized to [0,1.0]
        Xc = np.expand_dims(Xc, axis = 1) #add channel=1 to the data, n * c * H * W
        Yc = Yc.astype('int64')
        ton = len(Xc)
        trn = int(np.round(ton*0.9))
        Xc = Xc[trn:,:,:,:]
        Yc = Yc[trn:,:]

        data_pMCI = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_2_MRI/ADNI_2_pMCI.mat')
        Xpm, Ypm = data_pMCI['X'], data_pMCI['Y']
        Xpm = Xpm.astype('float32')
        Xpm /= 255                         #normalized to [0,1.0]
        Xpm = np.expand_dims(Xpm, axis = 1) #add channel=1 to the data, n * c * H * W
        Ypm = Ypm.astype('int64')*0 + 2
        ton = len(Xpm)
        trn = int(np.round(ton*0.9))
        Xpm = Xpm[trn:,:,:,:]
        Ypm = Ypm[trn:,:]
        
        data_sMCI = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_2_MRI/ADNI_2_sMCI.mat')
        Xsm, Ysm = data_sMCI['X'], data_sMCI['Y']
        Xsm = Xsm.astype('float32')
        Xsm /= 255                         #normalized to [0,1.0]
        Xsm = np.expand_dims(Xsm, axis = 1) #add channel=1 to the data, n * c * H * W
        Ysm = Ysm.astype('int64')*0 + 2
        ton = len(Xsm)
        trn = int(np.round(ton*0.9))
        Xsm = Xsm[trn:,:,:,:]
        Ysm = Ysm[trn:,:]
        
        XX = np.vstack((Xa,Xc, Xpm, Xsm))
        YY = np.vstack((Ya,Yc, Ypm, Ysm))
        
        self.images = torch.from_numpy(XX) 
        self.targets = torch.from_numpy(YY) 
        #self.transform = transform

    def __getitem__(self, index):
        x = self.images[index]
        y = self.targets[index]
        return x, y

    def __len__(self):
        return len(self.images)

class ADNI1_Dataset_train(Dataset):
    def __init__(self, transform = None):
        #mat_path = './data/ADNI_1_MRI'
        data_AD = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_1_MRI/ADNI_1_AD.mat')
        Xa, Ya = data_AD['X'], data_AD['Y']
        Xa = Xa.astype('float32')
        Xa /= 255                         #normalized to [0,1.0]
        Xa = np.expand_dims(Xa, axis = 1) #add channel=1 to the data, n * c * H * W
        Ya = Ya.astype('int64')
        ton = len(Xa)
        trn = int(np.round(ton*0.9))
        Xa = Xa[0:trn,:,:,:]
        Ya = Ya[0:trn,:]
        
        data_CN = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_1_MRI/ADNI_1_CN.mat')
        Xc, Yc = data_CN['X'], data_CN['Y']
        Xc = Xc.astype('float32')
        Xc /= 255                         #normalized to [0,1.0]
        Xc = np.expand_dims(Xc, axis = 1) #add channel=1 to the data, n * c * H * W
        Yc = Yc.astype('int64')
        ton = len(Xc)
        trn = int(np.round(ton*0.9))
        Xc = Xc[0:trn,:,:,:]
        Yc = Yc[0:trn,:]

        data_pMCI = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_1_MRI/ADNI_1_pMCI.mat')
        Xpm, Ypm = data_pMCI['X'], data_pMCI['Y']
        Xpm = Xpm.astype('float32')
        Xpm /= 255                         #normalized to [0,1.0]
        Xpm = np.expand_dims(Xpm, axis = 1) #add channel=1 to the data, n * c * H * W
        Ypm = Ypm.astype('int64')*0 + 2
        ton = len(Xpm)
        trn = int(np.round(ton*0.9))
        Xpm = Xpm[0:trn,:,:,:]
        Ypm = Ypm[0:trn,:]
        
        data_sMCI = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_1_MRI/ADNI_1_sMCI.mat')
        Xsm, Ysm = data_sMCI['X'], data_sMCI['Y']
        Xsm = Xsm.astype('float32')
        Xsm /= 255                         #normalized to [0,1.0]
        Xsm = np.expand_dims(Xsm, axis = 1) #add channel=1 to the data, n * c * H * W
        Ysm = Ysm.astype('int64')*0 + 2
        ton = len(Xsm)
        trn = int(np.round(ton*0.9))
        Xsm = Xsm[0:trn,:,:,:]
        Ysm = Ysm[0:trn,:]
        
        XX = np.vstack((Xa,Xc, Xpm, Xsm))
        YY = np.vstack((Ya,Yc, Ypm, Ysm))
        
        self.images = torch.from_numpy(XX) 
        self.targets = torch.from_numpy(YY) 
        #self.transform = transform

    def __getitem__(self, index):
        x = self.images[index]
        y = self.targets[index]
        return x, y

    def __len__(self):
        return len(self.images)

class ADNI1_Dataset_test(Dataset):
    def __init__(self, transform = None):
        #mat_path = './data/ADNI_1_MRI'
        data_AD = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_1_MRI/ADNI_1_AD.mat')
        Xa, Ya = data_AD['X'], data_AD['Y']
        Xa = Xa.astype('float32')
        Xa /= 255                         #normalized to [0,1.0]
        Xa = np.expand_dims(Xa, axis = 1) #add channel=1 to the data, n * c * H * W
        Ya = Ya.astype('int64')
        ton = len(Xa)
        trn = int(np.round(ton*0.9))
        Xa = Xa[trn:,:,:,:]
        Ya = Ya[trn:,:]
        
        data_CN = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_1_MRI/ADNI_1_CN.mat')
        Xc, Yc = data_CN['X'], data_CN['Y']
        Xc = Xc.astype('float32')
        Xc /= 255                         #normalized to [0,1.0]
        Xc = np.expand_dims(Xc, axis = 1) #add channel=1 to the data, n * c * H * W
        Yc = Yc.astype('int64')
        ton = len(Xc)
        trn = int(np.round(ton*0.9))
        Xc = Xc[trn:,:,:,:]
        Yc = Yc[trn:,:]

        data_pMCI = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_1_MRI/ADNI_1_pMCI.mat')
        Xpm, Ypm = data_pMCI['X'], data_pMCI['Y']
        Xpm = Xpm.astype('float32')
        Xpm /= 255                         #normalized to [0,1.0]
        Xpm = np.expand_dims(Xpm, axis = 1) #add channel=1 to the data, n * c * H * W
        Ypm = Ypm.astype('int64')*0 + 2
        ton = len(Xpm)
        trn = int(np.round(ton*0.9))
        Xpm = Xpm[trn:,:,:,:]
        Ypm = Ypm[trn:,:]
        
        data_sMCI = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/ADNI_1_MRI/ADNI_1_sMCI.mat')
        Xsm, Ysm = data_sMCI['X'], data_sMCI['Y']
        Xsm = Xsm.astype('float32')
        Xsm /= 255                         #normalized to [0,1.0]
        Xsm = np.expand_dims(Xsm, axis = 1) #add channel=1 to the data, n * c * H * W
        Ysm = Ysm.astype('int64')*0 + 2
        ton = len(Xsm)
        trn = int(np.round(ton*0.9))
        Xsm = Xsm[trn:,:,:,:]
        Ysm = Ysm[trn:,:]
        
        XX = np.vstack((Xa,Xc, Xpm, Xsm))
        YY = np.vstack((Ya,Yc, Ypm, Ysm))
        
        self.images = torch.from_numpy(XX) 
        self.targets = torch.from_numpy(YY) 
        #self.transform = transform

    def __getitem__(self, index):
        x = self.images[index]
        y = self.targets[index]
        return x, y

    def __len__(self):
        return len(self.images)

class AIBL_Dataset_test(Dataset):
    def __init__(self, transform = None):
        #mat_path = './data/ADNI_1_MRI'
        data_AD1 = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/AIBL/AIBL_AD_1.mat')
        data_AD2 = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/AIBL/AIBL_AD_2.mat')
        Xa1 = data_AD1['AD_feats1']
        Xa2 = data_AD2['AD_feats2']
        Xa1 = Xa1.astype('float32')
        Xa1 /= 255                         #normalized to [0,1.0]
        Xa2 = Xa2.astype('float32')
        Xa2 /= 255                         #normalized to [0,1.0]
        Xa1 = np.expand_dims(Xa1, axis = 1) #add channel=1 to the data, n * c * H * W
        Xa2 = np.expand_dims(Xa2, axis = 1) #add channel=1 to the data, n * c * H * W
        Xa = np.vstack((Xa1, Xa2))
        Ya = np.zeros((len(Xa),1)) 
        Ya = Ya.astype('int64')
        ton = len(Xa)
        trn = int(np.round(ton*0.9))
        Xa = Xa[trn:,:,:,:]
        Ya = Ya[trn:,:]
        
        data_CN = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/AIBL/AIBL_NC.mat')
        Xc = data_CN['NC_feats']
        Xc = Xc.astype('float32')
        Xc /= 255                         #normalized to [0,1.0]
        Xc = np.expand_dims(Xc, axis = 1) #add channel=1 to the data, n * c * H * W
        Yc = np.zeros((len(Xc),1)) + 1
        Yc = Yc.astype('int64')
        ton = len(Xc)
        trn = int(np.round(ton*0.9))
        Xc = Xc[trn:,:,:,:]
        Yc = Yc[trn:,:]

        data_pMCI = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/AIBL/AIBL_MCI.mat')
        Xpm = data_pMCI['MCI_feats']
        Xpm = Xpm.astype('float32')
        Xpm /= 255                         #normalized to [0,1.0]
        Xpm = np.expand_dims(Xpm, axis = 1) #add channel=1 to the data, n * c * H * W
        Ypm = np.zeros((len(Xpm),1)) + 2
        Ypm = Ypm.astype('int64')
        ton = len(Xpm)
        trn = int(np.round(ton*0.9))
        Xpm = Xpm[trn:,:,:,:]
        Ypm = Ypm[trn:,:]
        
        
        XX = np.vstack((Xa,Xc, Xpm))
        YY = np.vstack((Ya,Yc, Ypm))
        
        self.images = torch.from_numpy(XX) 
        self.targets = torch.from_numpy(YY) 
        #self.transform = transform

    def __getitem__(self, index):
        x = self.images[index]
        y = self.targets[index]
        return x, y

    def __len__(self):
        return len(self.images)

class AIBL_Dataset_train(Dataset):
    def __init__(self, transform = None):
        #mat_path = './data/ADNI_1_MRI'
        data_AD1 = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/AIBL/AIBL_AD_1.mat')
        data_AD2 = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/AIBL/AIBL_AD_2.mat')
        Xa1 = data_AD1['AD_feats1']
        Xa2 = data_AD2['AD_feats2']
        Xa1 = Xa1.astype('float32')
        Xa1 /= 255                         #normalized to [0,1.0]
        Xa2 = Xa2.astype('float32')
        Xa2 /= 255                         #normalized to [0,1.0]
        Xa1 = np.expand_dims(Xa1, axis = 1) #add channel=1 to the data, n * c * H * W
        Xa2 = np.expand_dims(Xa2, axis = 1) #add channel=1 to the data, n * c * H * W
        Xa = np.vstack((Xa1, Xa2))
        Ya = np.zeros((len(Xa),1)) 
        Ya = Ya.astype('int64')
        ton = len(Xa)
        trn = int(np.round(ton*0.9))
        Xa = Xa[1:trn,:,:,:]
        Ya = Ya[1:trn,:]
        
        data_CN = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/AIBL/AIBL_NC.mat')
        Xc = data_CN['NC_feats']
        Xc = Xc.astype('float32')
        Xc /= 255                         #normalized to [0,1.0]
        Xc = np.expand_dims(Xc, axis = 1) #add channel=1 to the data, n * c * H * W
        Yc = np.zeros((len(Xc),1)) + 1
        Yc = Yc.astype('int64')
        ton = len(Xc)
        trn = int(np.round(ton*0.9))
        Xc = Xc[1:trn,:,:,:]
        Yc = Yc[1:trn,:]

        data_pMCI = sio.loadmat('/shenlab/lab_stor6/ekyang/Dataset/AIBL/AIBL_MCI.mat')
        Xpm = data_pMCI['MCI_feats']
        Xpm = Xpm.astype('float32')
        Xpm /= 255                         #normalized to [0,1.0]
        Xpm = np.expand_dims(Xpm, axis = 1) #add channel=1 to the data, n * c * H * W
        Ypm = np.zeros((len(Xpm),1)) + 2
        Ypm = Ypm.astype('int64')
        ton = len(Xpm)
        trn = int(np.round(ton*0.9))
        Xpm = Xpm[1:trn,:,:,:]
        Ypm = Ypm[1:trn,:]
        
        
        XX = np.vstack((Xa,Xc, Xpm))
        YY = np.vstack((Ya,Yc, Ypm))
        
        self.images = torch.from_numpy(XX) 
        self.targets = torch.from_numpy(YY) 
        #self.transform = transform

    def __getitem__(self, index):
        x = self.images[index]
        y = self.targets[index]
        return x, y

    def __len__(self):
        return len(self.images)


