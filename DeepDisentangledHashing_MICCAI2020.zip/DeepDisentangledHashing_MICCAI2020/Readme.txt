train.py is the main file, which contains the model initilization, training and also the momentum updating.
model.py implements the used network architecture.
losses.py may contain the needed loss functions, which are modified from other implementations.
data_loader.py helps to load data.

